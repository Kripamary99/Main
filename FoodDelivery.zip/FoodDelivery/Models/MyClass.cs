﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    [MetadataType(typeof(Providerdata))]
    public partial class Provider
    {
        public string Username { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password Mismatch")]
        public string CPassword { get; set; }
    }

    public partial class Providerdata
    {
        public string ProviderName { get; set; }
        public string OwnerName { get; set; }
        public string ContactPerson { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        [Display(Name="Year of Starting")]
        public string StartedYear { get; set; }
    }

    [MetadataType(typeof(Logindata))]
    public partial class Login
    {

    }

    public partial class Logindata
    {
        public string Username { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    [MetadataType(typeof(FoodItemdata))]
    public partial class FoodItem
    {
        public HttpPostedFileBase File { get; set; }
    }

    public partial class FoodItemdata
    {
        public string FoodItemName { get; set; }
        public Nullable<int> CategoryID { get; set; }
        public Nullable<int> ProviderID { get; set; }
        public string Photo { get; set; }
        public Nullable<bool> IsDeleted { get; set; }
        public string Price { get; set; }
        [DataType(DataType.MultilineText)]
        public string ItemDetail { get; set; }}
    
    public partial class DeliverPlace
    {
        [Display(Name="Pincode")]

        [DataType(DataType.MultilineText)]
        public string Pincodes { get; set; }
    }

    public partial class Customer
    {
        public string Username { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password Mismatch")]
        public string CPassword { get; set; }
    }

    [MetadataType(typeof(Orderdata))]
    public partial class Order
    {
    }

    public partial class Orderdata
    {

        public Nullable<int> CustomerID { get; set; }
        public Nullable<int> Pincode { get; set; }
        public Nullable<int> FoodItemID { get; set; }
        public string Quantity { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> CreatedOn { get; set; }

    }

   

}