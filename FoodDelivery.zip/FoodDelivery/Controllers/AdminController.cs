﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodDelivery.Models;

namespace FoodDelivery.Controllers
{
    public class AdminController : Controller
    {
        FoodDeliveryEntities Db = new FoodDeliveryEntities();

        public ActionResult newProvideList()
        {
            var model = Db.Providers.Where(a=>a.Login.IsAccepted==false && a.Login.IsRejected==false && a.Login.IsDeleted==false).ToList();
            return View(model);
        }

        public ActionResult acceptProvider(int? id)
        {
            if (id > 0)
            {
                Login log = Db.Logins.Find(id);
                log.IsAccepted = true;
                Db.SaveChanges();
            }
            return RedirectToAction("newProvideList");
        }

        public ActionResult rejectProvider(int? id)
        {
            if (id > 0)
            {
                Login log = Db.Logins.Find(id);
                log.IsRejected = true;
                Db.SaveChanges();
            }
            return RedirectToAction("newProvideList");
        }

        public ActionResult activeProviders()
        {
            var model = Db.Providers.Where(a => a.Login.IsAccepted == true && a.Login.IsRejected == false && a.Login.IsDeleted == false).ToList();
            return View(model);
        }

        public ActionResult newBranchRequest()
        {
            var branch = Db.Branches.Where(a => a.IsAccepted == false && a.IsRejected == false).ToList();
            return View(branch);
        }

        public ActionResult acceptBranch(int? id,int? pid)
        {
            return View();
        }

        [HttpPost]
        public ActionResult acceptBranch(int? id, int? pid,DeliverPlace dplace)
        {
            DeliverPlace place = new DeliverPlace();
            place.ProviderID = pid;

            Branch branch = Db.Branches.Find(id);
            branch.IsAccepted = true;
            Db.SaveChanges();

           string[] arrayValues = dplace.Pincodes.Split(',');
           foreach(string item in arrayValues)
           {
               place.Pincode = Convert.ToInt32(item);
               Db.DeliverPlaces.Add(place);
               Db.SaveChanges();
              
           }
           return RedirectToAction("newBranchRequest");
        }

        public ActionResult rejectBranch(int? id)
        {
            Branch branch = Db.Branches.Find(id);
            branch.IsRejected = true;
            Db.SaveChanges();
            return RedirectToAction("newBranchRequest");
        }

        public ActionResult NewOrder()
        {
            var model = Db.Orders.Where(a => a.IsDeliverd == false && a.IsDeleted == false && a.CartStatus==true).ToList();
            return View(model);
        }

        public ActionResult deliver(int? id)
        {
            Order order = Db.Orders.Find(id);
            order.IsDeliverd = true;
            Db.SaveChanges();
            return RedirectToAction("NewOrder");
        }
        public ActionResult deliverboyOrderView()
        {
            var v = Db.Orders.ToList();
            return View(v);
        }

        
    }
}