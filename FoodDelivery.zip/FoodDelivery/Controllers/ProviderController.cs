﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodDelivery.Models;

namespace FoodDelivery.Controllers
{
    public class ProviderController : Controller
    {
        FoodDeliveryEntities Db = new FoodDeliveryEntities();
        // GET: Provider
        public ActionResult addBranch()
        {
            return View();
        }
     

        public ActionResult branchList()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var provider = Db.Providers.Where(a => a.LoginID == LoginID).ToList();
            int providerID = provider[0].ProviderID;
            var model = Db.Branches.Where(a => a.IsAccepted == true && a.IsRejected == false && a.ProviderID == providerID).ToList();
            return View(model);
        }


        [HttpPost]
        public ActionResult addBranch(Branch branch)
        {
            if(ModelState.IsValid)
            {
                int LoginID = Convert.ToInt32(Session["LoginID"]);
                var model = Db.Providers.Where(a => a.LoginID == LoginID).ToList();
                branch.ProviderID = model[0].ProviderID;
                branch.IsAccepted = false;
                branch.IsRejected = false;
                Db.Branches.Add(branch);
                Db.SaveChanges();
                return RedirectToAction("addBranch");
            }
          
            return View();
        }

        public ActionResult addFoodItem()
        {
            ViewBag.Category = Db.Categories.ToList();
            return View();
        }

        [HttpPost]
        public ActionResult addFoodItem(FoodItem item)
        {
            ViewBag.Category = Db.Categories.ToList();
            if(ModelState.IsValid)
            { 
                int LoginID = Convert.ToInt32(Session["LoginID"]);

                var model = Db.Providers.Where(a => a.LoginID == LoginID).ToList();

                item.ProviderID = model[0].ProviderID;
                item.Photo = "../Content/FoodItem/" + item.File.FileName;
                item.IsDeleted = false;
                Db.FoodItems.Add(item);
                Db.SaveChanges();
                item.File.SaveAs(Server.MapPath("~/Content/FoodItem/" + item.File.FileName));
                return RedirectToAction("foodItems");

            }
            return View();
        }

        public ActionResult foodItems()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);

            var model = Db.Providers.Where(a => a.LoginID == LoginID).ToList();
            int providerId = model[0].ProviderID;
            var items = Db.FoodItems.Where(a=>a.ProviderID==providerId).ToList();
            return View(items);
        }
    }
}