﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodDelivery.Models;

namespace FoodDelivery.Controllers
{
    public class AccountController : Controller
    {
        FoodDeliveryEntities Db = new FoodDeliveryEntities();
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Login log)
        {
            var result = Db.Logins.Where(a => a.Username == log.Username && a.Password == log.Password && a.IsDeleted == false).ToList();
            if(result.Count>0)
            {
                Session["LoginID"] = result[0].LoginID;

                if(result[0].RoleID==1)
                {
                    return RedirectToAction("../Admin/newBranchRequest");
                }
                else if(result[0].RoleID==2 && result[0].IsAccepted==true && result[0].IsRejected==false)
                {
                    return RedirectToAction("../Provider/addBranch");
                }
                else if (result[0].RoleID == 3)
                {
                    return RedirectToAction("../Customer/myOrders");
                }
                else if (result[0].RoleID == 2 && result[0].IsAccepted == false && result[0].IsRejected == false)
                {
                    ViewBag.Message = "Wait for Admin Authorization";
                }

            }
            else
            {
                ViewBag.Message = "Incorrect Username or Password";
            }
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}