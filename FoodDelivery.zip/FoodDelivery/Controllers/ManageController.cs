﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodDelivery.Models;

namespace FoodDelivery.Controllers
{
    public class ManageController : Controller
    {
        FoodDeliveryEntities Db = new FoodDeliveryEntities();
        // GET: Manage
        public ActionResult newProvider()
        {
            return View();
        }

        [HttpPost]
        public ActionResult newProvider(Provider pro)
        {
            if (ModelState.IsValid)
            {
                Login log = new Login();
                log.Username = pro.Username;
                log.Password = pro.Password;
                log.RoleID = 2;
                log.IsAccepted = log.IsDeleted = log.IsRejected = false;
                log.CreatedOn = DateTime.Today.Date;
                Db.Logins.Add(log);
                Db.SaveChanges();

                pro.LoginID = Db.Logins.Max(a => a.LoginID);
                Db.Providers.Add(pro);
                Db.SaveChanges();
                return RedirectToAction("newProvider");
            }

            return View(pro);
        }

        public ActionResult newCustomer()
        {
            return View();
        }

        [HttpPost]
        public ActionResult newCustomer(Customer cus)
        {
            if (ModelState.IsValid)
            {
                Login log = new Login();
                log.Username = cus.Username;
                log.Password = cus.Password;
                log.RoleID = 3;
                log.IsAccepted = log.IsDeleted = log.IsRejected = false;
                log.CreatedOn = DateTime.Today.Date;
                Db.Logins.Add(log);
                Db.SaveChanges();

                cus.LoginID = Db.Logins.Max(a => a.LoginID);
                Db.Customers.Add(cus);
                Db.SaveChanges();
                return RedirectToAction("newCustomer");
            }
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
    }
}