﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodDelivery.Models;

namespace FoodDelivery.Controllers
{
    public class CustomerController : Controller
    {

        FoodDeliveryEntities Db = new FoodDeliveryEntities();
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }
        public  ActionResult Edit(int id)
        {
            var cus = Db.Customers.Find(id);
            return View(cus);


        }
        [HttpPost]
        public ActionResult Edit(Customer c,int id)
        {
            var cus = Db.Customers.Find(id);
            Db.SaveChanges();

            return View();

        }

        public ActionResult SerachItems()
        {
            var result = Db.search(0000,0).ToList();
            return View(result);
        }

        [HttpPost]
        public ActionResult SerachItems(string pincode)
        {
            ViewBag.pincode = pincode;
            var result = Db.search(Convert.ToInt32(pincode),0).ToList();
            return View(result);
        }

        public ActionResult orderNow(int? id,string pin)
        {
            Session["pincode"] = pin;
            Session["fooditemid"] = id;
            var model = Db.FoodItems.Where(a => a.FoodItemID == id).ToList();
            return View(model);
        }

        [HttpPost]
        public ActionResult orderNow(int? id,string pin, string Quantity)
        {
            ViewBag.pincode = pin;
            Order order=new Order();
            order.Quantity=Quantity;
            int pino = Convert.ToInt32(Session["pincode"]);
                int LoginID = Convert.ToInt32(Session["LoginID"]);
                var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
                int CustomerID = model[0].CustomerID;
                order.CustomerID = CustomerID;
                order.Pincode = pino;
                order.FoodItemID = Convert.ToInt32(Session["fooditemid"]);
                order.IsDeleted = false;
                order.IsDeliverd = false;
                order.CartStatus = false;
                Db.Orders.Add(order);
                Db.SaveChanges();
                return RedirectToAction("cart");
            
        }

        public ActionResult cart()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            var order = Db.Orders.Where(a => a.CustomerID == CustomerID && a.IsDeliverd==false && a.CartStatus==false&& a.IsDeleted==false).ToList();
            return View(order);
        }

        public ActionResult checkout()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            var order = Db.Orders.Where(a => a.CustomerID == CustomerID && a.IsDeliverd == false && a.CartStatus == false && a.IsDeleted == false).ToList();
            return View(order);
        }

        [HttpPost]
        public ActionResult checkout(int? id)
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            var order = Db.Orders.Where(a => a.CustomerID == CustomerID && a.IsDeliverd == false && a.CartStatus == false && a.IsDeleted == false).ToList();
            foreach(var item in order)
            {
                int orderid=item.OrderID;
                Order or = Db.Orders.Find(orderid);
                or.CartStatus = true;
                Db.SaveChanges();
            }
            return RedirectToAction("cart");
        }

        public ActionResult myOrders()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            var order = Db.Orders.Where(a=>a.CustomerID==CustomerID).ToList();
            return View(order);
        }

        public ActionResult cancelOrder(int? id)
        {
            Order order = Db.Orders.Find(id);
            order.IsDeleted = true;
            Db.SaveChanges();
            return RedirectToAction("myOrders");
        }

        public ActionResult deleteCart(int? id)
        {
            Order order = Db.Orders.Find(id);
            order.IsDeleted = true;
            Db.SaveChanges();
            return RedirectToAction("cart");
        }

        public ActionResult cartSide()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            ViewBag.order = Db.Orders.Where(a => a.CustomerID == CustomerID && a.IsDeliverd == false && a.CartStatus == false && a.IsDeleted == false).ToList();

            return View();
        }
        public ActionResult cartCount()
        {
            int LoginID = Convert.ToInt32(Session["LoginID"]);
            var model = Db.Customers.Where(a => a.LoginID == LoginID).ToList();
            int CustomerID = model[0].CustomerID;
            ViewBag.itemCount = Db.Orders.Where(a => a.CustomerID == CustomerID && a.IsDeliverd == false && a.CartStatus == false && a.IsDeleted == false).Count();

            return View();
        }




    }
}